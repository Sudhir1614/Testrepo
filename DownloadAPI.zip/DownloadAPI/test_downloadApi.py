from urllib import request
from Google import Create_Service
import os
import io
from googleapiclient.http import MediaIoBaseDownload

CLIENT_SECRET_FILE = 'credentials.json'
API_NAME = 'drive'
API_VERSION = 'v3'
SCOPES = ['https://www.googleapis.com/auth/drive']

service = Create_Service(CLIENT_SECRET_FILE, API_NAME, API_VERSION, SCOPES)

file_ids = ['a9bd1bdd4b649fd0ce97da1b375d9493', 'a9bd1bdd4b649fd0ce97da1b375d9493']
file_names = ['20191027_204931.jpg', '20191027_205051.jpg']

for file_id, file_name in zip(file_ids, file_names):
    request = service.files().get_media(fileId=file_id)

    fh = io.BytesIO()
    downloader = MediaIoBaseDownload(fd=fh, request=request)

    done = False

    while not done:
        status, done = downloader.next_chunk()
        print('Download Prgress {0}'.format(status.progress()*100))

    fh.seek(0)

    with open(os.path.join('./Random Files', file_name), 'wb') as f:
        f.write(fh.read())
        f.close()
